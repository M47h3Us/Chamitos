#Ex5
soma_reversa = 100
menos = 1
soma_infinita = 1
soma = 1
while soma_infinita != 100:
    soma_infinita = soma_infinita + soma
    print(soma_infinita)

while soma_reversa != 1:
    soma_reversa = soma_reversa - menos
    print(soma_reversa)