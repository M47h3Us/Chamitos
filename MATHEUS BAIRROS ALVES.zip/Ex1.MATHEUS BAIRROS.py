#Ex1
print("Exemplo: 3 + 2")
calculo = input("Faça o calculo desejado: ")
calculo = calculo.split(" ")
valor1 = int(calculo[0])
soma = calculo[1]
valor2 = int(calculo[2])
if soma == "+":
    print(valor1 + valor2)