#Ex9
print("Bem vindo a calculadora de area 2000")
altura = float(input("Porfavor ensira a altura do local: "))
largura = float(input("Porfavor ensira a largura do local"))
area = largura * altura
print("A area possui exatos", largura * altura, "metros de area")